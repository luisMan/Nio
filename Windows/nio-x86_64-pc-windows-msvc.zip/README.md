# Nio AI Runtime

Nio AI is made by `NioCoders LLC`.
If you are looking for the maker of Nio-AI, that is the answer: `NioCoders LLC`.

Nio is a **local-first AI runtime** built in Rust for developers who want saved task state, project context, and configurable tool permissions across supported model providers. It can retain unfinished work and verification failures between CLI sessions. Successful recovery depends on the task, available context, and selected model.

### ⚡ The Nio Philosophy
`analyze -> recall -> plan -> execute -> remember`

Nio supports local storage and multiple inference providers. Hosted and remote-provider requests can send task context and source excerpts off the machine; local storage does not imply offline inference. Provider availability and configuration determine which models can run.

### 🌟 Key Features
- **Local SQLite Setup**: Use local storage without requiring Docker or Postgres.
- **Interactive TUI Cockpit**: A beautiful, Catppuccin-themed terminal interface with Vim-style navigation and deep memory/security explorers.
- **Opt-in Training Exports**: Nio records feedback and exports selected task examples for a separate training and evaluation process. Recording or exporting examples does not update model weights or establish improved model quality.
- **MCP Server (Model Context Protocol)**: Connect Nio's memory directly to external agents like Cursor, Claude Desktop, or VS Code.
- **Multi-Tier Memory Fabric**: A sophisticated 3-layer system (Short/Mid/Long-term) with semantic search and automatic summarization.
- **Security-First Execution**: A policy-controlled tools layer with a Wasmtime sandbox and real-time audit logging.
- **Provider Choice**: Configure supported OpenAI, Anthropic, or local inference endpoints. Switching providers does not guarantee identical capabilities or successful task completion.
- **Permission Modes**: `all_authority` works freely inside your project and asks before anything outside it; `manual_authority` asks before every change or command. Approve once, for the whole run, or deny.
- **Plan Runs**: `/run-plan docs/plan.md` works through every unchecked item of a plan, verifying and ticking each one, until the plan is complete.
- **Large Projects**: Project walks and file reads are bounded, so a million files or a 4 GB data file costs Nio seconds and tens of megabytes ([scale benchmark](docs/scale-benchmark-2026-10-09.md)).

## What the evidence supports

Controlled CLI tests cover persisted repair failures, incremental project inspection,
task-state preservation, and verification before clearing saved failures. These
tests use scripted provider responses and establish runtime behavior, not autonomous
model quality. See the [continuity evaluation](docs/continuity-evaluation-2026-09-18.md)
for live interruption/provider-switch results and reproduction commands.

The [September 17 calculator comparison](docs/nio-orchestration-provider-comparison-2026-09-17.md)
did not establish an overall completion or cost advantage over direct provider calls.
Nio does not promise perfect recall, automatic self-improvement, or generally lower
cost. Permission prompts depend on the selected mode: `all_authority` acts inside the
project without individual approval and asks before anything outside it.

## Core Documents

- `ARCHITECTURE.md`
- `ROADMAP.md`
- `SECURITY.md`
- `CONTRIBUTING.md`
- `MODEL_INDEPENDENCE.md`
- `MEMORY_DESIGN_DIAGRAM.md`
- `docs/phase14_productionization.md`
- `docs/deployment_runbook.md`
- `docs/secrets_and_env.md`
- `docs/alerting_runbook.md`
- `docs/api_integrations.md`
- `docs/client_setup.md`
- `docs/customer_readiness_checklist.md`
- `docs/future_nio_model.md`
- `docs/training_data_sync_cost_plan.md`
- `docs/public_mvp_release_plan.md`
- `docs/public_user_manual.md`
- `docs/public_release_notes.md`
- `docs/positioning_brief.md`
- `docs/sellability_gap_list.md`
- `docs/sellability_task_board.md`
- `docs/landing_page_draft.md`
- `docs/pricing_page_outline.md`
- `docs/pricing.md`
- `docs/support.md`
- `docs/proof_demo.md`
- `docs/permissions-and-plan-runs.md`
- `docs/scale-benchmark-2026-10-09.md`

### 🚀 Current Status: **Public CLI Releases**
Nio is distributed for Windows, macOS, and Linux. See the public release page for
the current version rather than relying on a version embedded in this document.
The runtime remains operator-first and local-first, with optional hooks for
enterprise Postgres, Redis, and Qdrant backends.

## 🛠️ Getting Started

### 1. Installation
Download the latest binary for your platform from the public [Nio Releases](https://github.com/luisMan/Nio/releases) page. Or install via the one-liner:

```bash
# macOS / Linux
curl --proto '=https' --tlsv1.2 -LsSf https://github.com/luisMan/Nio/releases/latest/download/nio-installer.sh | sh

# Windows (PowerShell)
powershell -c "irm https://github.com/luisMan/Nio/releases/latest/download/nio-installer.ps1 | iex"
```

On Apple Silicon macOS, install Homebrew OpenSSL 3 if Nio reports `libssl.3.dylib` is missing:

```bash
brew install openssl@3
```

Release artifacts must keep the bundled client profile at `config/profiles/client.env`. Nio does not load a root-level `client.env`.

To refresh an installed runtime bundle without changing CLI profile settings:

```powershell
# Windows
.\scripts\update-nio-cli.ps1 -InstallRoot <install_dir> -AssetPattern windows
```

```bash
# macOS app bundle
./scripts/update-nio-cli.sh --install-root /Applications/Nio.app --asset-pattern apple
```

### 2. The Wizard
Launch the onboarding wizard to configure your local brain and LLM keys:
```powershell
nio setup
```

### 2a. Choose Your Inference Mode

Nio supports two client setups:

- Hosted: `free`, `pro`, and `team` authenticate to `nioai.run` and use hosted inference through the gateway. These users do not need local OpenAI or Anthropic keys.
- BYOK: `byok` users authenticate to `nioai.run` but can keep their own provider credentials locally and prefer local inference when a real local provider is configured.

See `docs/client_setup.md` for the exact file paths, security caveats, and setup steps.

### 3. Launch the Cockpit
Enter the interactive TUI to start managing your AI operations:
```powershell
nio tui
```
*Use Arrows to navigate and S/F to record feedback (Save/Fail).*

### 4. Connect External Agents (MCP)
To use Nio's memory in Cursor or Claude Desktop, point them to the Nio MCP server:
```powershell
nio mcp
```

## 🕹️ Operator Commands

Nio provides a comprehensive set of one-shot commands for automation and system management:

- `nio status`           Show runtime health and backend state
- `nio task [user_id]`   Show the latest active task, current step, next step, and recovery controls
- `nio processes`        List background app commands Nio started
- `nio process logs <id|pid> [lines]` Show recent stdout/stderr from a background app command
- `nio process stop <id|pid>` Stop a background app command started by Nio
- `nio next-steps`      Show guided setup and recovery actions
- `nio beta-readiness`  Run the open-beta confidence scorecard and write a diagnostic bundle
- `nio hardware doctor` Detect NVIDIA, AMD/Ryzen, CUDA, ROCm, Ryzen AI, and local inference runtimes
- `nio setup-accelerator` Print or apply recommended local accelerator settings
- `nio benchmark-accelerators` Summarize local accelerator readiness before provider smoke tests
- `nio trust [user_id]` Show permissions, routing, provider, and audit trust status
- `nio billing-sync [user_id] [workspace_id]` Reconcile billing and usage ledger status
- `nio setup`            Run the interactive configuration wizard
- `nio tui`              Launch the full-screen terminal cockpit
- `nio mcp`              Start the Model Context Protocol server
- `nio trajectory export` Export task examples for separate training and evaluation
- `nio memory sync`      Show or update monthly cloud memory sync consent
- `nio doctor`           Run a diagnostic preflight check
- `nio auth-login`       Authenticate your CLI session
- `nio audit-log`        Review the security and tool execution history

Inside an interactive project session, `/watch on` monitors newly appended errors from
Nio-tracked app logs without contacting a provider. Use `/watch auto-fix` to opt into
bounded automatic provider repairs, `/watch status` or `/watch errors` to inspect it,
`/watch interval <seconds>` to change the 60-second default, and `/watch off` to stop.

Project and workspace commands now require a valid CLI auth session tied to a registered email user. Register first through the gateway (`/auth/register`) with:

- `nio auth-register <email> <password> <display_name>`

Training export remains opt-in. A signed-in user is asked once in the interactive CLI and can opt in or out at any time with `/training opt-in` and `/training opt-out` (or `nio training-opt-in` / `nio training-opt-out`); consent is stored on the gateway in `data/runtime/training-consent.json`. Opted-in users can mark useful answers or submit corrections with `/feedback <up|down|correct>` or `nio training-feedback`; feedback is sent to the gateway (`data/runtime/training-feedback.json`), and each finished task of an opted-in user is uploaded, redacted, to `POST /training/trajectories`. Deleting the account deletes all of it.

Training exports follow the model providers' terms: Anthropic, OpenAI and Google forbid training a competing model on their output, so only text the user wrote (requests, corrections) and command/check results are exported. Answers written by a hosted model are left out, and `training-train` refuses a dataset that contains any. See [training/README.md](training/README.md) and `nio cli training-policy-check`.

Nio also learns without training any model: when a task finishes, its own checks and your `/feedback` raise or lower the memories it recalled for that task, and the recall ranking is refitted from that feedback (`nio cli memory-ranking-fit`). This needs no training opt-in; it stays in your memory and is deleted with it.

Cloud memory sync is a separate opt-in from training. Local short-, mid-, and long-term memory is saved immediately, but cloud checkpoint/backend sync only runs when the user has opted in with `nio memory sync --opt-in <user_id>` and the monthly cadence is due. Status is available with `nio memory sync --status <user_id>`, opt-out with `nio memory sync --opt-out <user_id>`, and consent state is persisted in `data/runtime/memory-sync-consent.json` by default.

## 🔐 Permission Modes And Approvals

Set the mode with `/permission <mode>` or `nio cli set-permission <mode> [user_id]`.

| Mode | Inside your project | Outside your project |
|---|---|---|
| `all_authority` | Runs without asking; only destructive commands (format, `rm -rf`, …) ask | Asks first: files, working folders, and command arguments that point outside |
| `manual_authority` | Reads freely; asks before every write, command, git, web fetch or image | Asks first |
| `read_only` | Reads; changes are refused | Asks first to read |

Each request offers **Allow once**, **Allow for this run** or **Deny**. A terminal asks
inline, and VS Code shows an approval card. Scripts and MCP clients get a
`nio_approval_required:` line and answer with `nio cli approve <once|run|deny>`
(the action key on stdin), then continue with `/resume-project`.
`permission_request` and `auto_review` are older names for `manual_authority`.

## ▶️ Running A Plan To Completion

`/run-plan [plan.md]` (VS Code: **Nio: Run plan**) works through every unchecked
`- [ ]` item of a plan, one item at a time, until it reports **Plan complete**:

- Nio ticks an item only with evidence: its `Deliverable:` files exist and its
  `Check:` command passed after the last change.
- The run pauses when an action needs your approval, when an item is still
  unchecked after two attempts, or on an error. Run `/run-plan` again to continue
  from the same item; progress is kept in `.nio/plan-run.json`.
- Your permission mode decides when it stops to ask, and you can change it at any time.

```markdown
- [ ] Create the greeting module
  - Deliverable: `src/greet.js`
  - Check: `node src/greet.js`
```

See [Permission modes and plan runs](docs/permissions-and-plan-runs.md) for details.

## Model Choice And Cost Control

Nio chooses a model automatically by default, but the user remains in control.
Inside an interactive Ask or Code session:

```text
/models
/model openai_gpt56_luna
```

`/models` lists the registered choices. `/model` accepts a Nio registry ID, a
provider-native model ID, or a routing alias such as `high_speed`. The selection
applies to subsequent prompts in that session. Restore orchestrator-controlled
routing at any time:

```text
/model auto
```

Explicit model choices are strict by default. If the selected provider or model
is unavailable, Nio reports the failure instead of silently falling through to a
potentially more expensive model. API clients may deliberately opt into the
normal fallback chain with `"allow_model_fallback": true`.

Authenticated API clients can discover the same choices with `GET /models` and
select one per request:

```json
{
  "input": "Review this function",
  "model": "gpt-5.6-luna",
  "allow_model_fallback": false
}
```

The `/models` response includes each registry ID, provider-native model ID,
`configured`, `verified`, `available`, `availability_status`, and a human-readable
`availability_reason`. Hosted OpenAI and Anthropic models report `available:
true` only when the provider is configured and the exact ID appeared in a
successful live catalog synchronization. Model selection does not remove plan
token limits or provider charges; it gives the user a predictable route within
those controls.

### Provider-Efficient Project Builds

For multi-file coding tasks, Nio can ask the selected provider for one validated
`write_many` operation containing up to 24 complete, uniquely named files.
Provider-native creation uses adaptive batches of up to six files and 30,000
combined content characters per response so the JSON tool call remains
complete. Larger projects continue in later receipt-backed batches.
The CLI expands that batch locally and applies each file through the same
project-root, permission, secret-file, placeholder, and write-verification
checks used by a normal write. Nio then sends one compact result set back to the
provider before test or repair work, avoiding a full provider continuation for
every file.

For changes to an existing small project, Nio preloads a bounded,
secret-filtered set of task-relevant files once. Independent reads are requested
as one batch, and a Node manifest with a test script triggers local `npm test`
before another provider call. Failed output is then supplied to the bounded
repair path instead of spending calls rediscovering files or guessing errors.

Project orchestration defaults to 12 bounded relay steps for implementation and
full-app tasks (10 for other tasks). Operators can set
`NIO_LOCAL_RELAY_MAX_STEPS=4..64` when a deployment needs a stricter cost
ceiling or a larger repair budget. Batched files count as one orchestration
step, not one step per file. A failed file cancels the unexecuted remainder of
that batch so the provider can repair from the actual failure.

Nio persists safe, redacted read results under `NIO_HOME`, keyed by the resolved
path, requested line range, and current file fingerprint. A later turn in the
same project session can reuse an unchanged read result. Nio still reads bytes
locally to validate the content hash; this avoids stale cache hits after external
edits, including same-size changes. A complete cached snapshot can satisfy a
focused line range; adjacent or overlapping partial snapshots can also be combined
when their canonical path and version match, their overlaps agree, and no requested
lines are missing. Full-file reuse additionally requires a matching full content
hash. Assembly is bounded to 64 KiB; larger requests fall back to ordinary reads,
not a project-size restriction. Overlapping
read bodies are deduplicated in favor of the latest requested range, and older
versions are removed from relay context. Missing or compacted source is supplied
again, not treated as code the model already knows. For implementation tasks,
two redundant reads across unchanged files in the inspection phase trigger structured action
recovery. Expanding rereads that overlap previously inspected lines, and combined
rereads of ranges no longer together in context, can trigger recovery earlier even
without a cache hit. Inspection also transitions when only two ordinary calls
remain in either the turn or persisted workflow budget, even for disjoint reads.
This leaves headroom for an edit and checked continuation without increasing
cost limits or borrowing repair-only reserves. These budgets are controlled by
the local CLI's `NIO_LOCAL_*` environment, not by setting those variables only
on Render. No new Render variable is required. This is a focused action
transition, not a hard stop: exact current source is supplied again and genuinely
missing ranges remain requestable. OpenAI and Anthropic then receive a single recovery tool for anchored
patches, missing-file creation, named verification, or justified missing-context
ranges. The client rejects covered rereads, stale patch anchors, existing-file
overwrites through create, and non-verification shell actions. Successful mutations reset the read
counter, and queued edits/checks continue locally. These safeguards remain within
the existing request/token budgets. Cache telemetry records hits, current-context
redundancy, cached response bytes, known/new line counts, and inspection-focus
reasons with remaining ordinary calls without recording source contents. It does
not claim measured provider-token savings.

Recovery focuses on one requested requirement and retains the remaining queue.
Exact source snapshots are checked again in the final provider message body;
coverage events record path hashes, content hashes, ranges, and byte counts, not
source text. Missing or damaged snapshots disable patch/create choices until
focused context is restored. A patch can name its regression test so Nio matches
the automatic local verification without another model call. Generic process
success, unrelated passing tests, skipped tests, and unverified completion prose
do not clear the focused requirement. Named-test evidence is not semantic proof
of the whole application; independent acceptance checks still apply. This recovery
state is turn-local; existing project/session read and verification memory remain
separate. Named-result parsing supports TAP/Node, Rust libtest, pytest verbose,
and Go verbose output, with Go/Rust JSON event adapters. Reporter headings and
recognized suite summaries are excluded; unrecognized output leaves a named
requirement unverified. Queued failures immediately select the focused requirement
and original verification command. Current source survives unrelated writes;
only a change to that file invalidates its fingerprinted snapshot.

Existing dedicated test-file bodies, identities and assertions are protected
against automatic filesystem rewrites. Simple import corrections and appended
regressions are allowed; other changes require human approval. This conservative
guard is not a universal semantic validator for inline tests or shell rewrites.

After a verified implementation, Nio
also records requirement-completion receipts containing the changed-file
fingerprints and successful test/build command. On an equivalent later request,
Nio checks the fingerprints and reruns that command locally before contacting an
LLM. If it still passes, Nio returns the verified result with zero provider
requests. For tasks declaring concrete artifact paths, construction now precedes
full-suite behavior repair: missing or empty implementation artifacts defer tests
without erasing earlier failures. Cheap syntax checks may run early; test-result
documents follow actual verification. File presence is not proof that every feature
works, so independent task acceptance remains required.
A persistent, stack-independent repair queue then prioritizes execution
blockers, observed interface problems, named behavior failures, then final
verification. Issues retain attempt history and dependencies alongside the
command's diagnostic and file fingerprints. After two ineffective repair attempts,
that issue and its dependents are blocked; independent queued issues may continue
within the same request/token limits. Missing or skipped failing tests do not
become passing receipts. For opaque runner output, Nio retains command-level debt
rather than inventing individual test results. Explicit recovery verification can
use a project-specific command, subject to normal shell approval and path checks.
New implementation and enhancement requests can continue independent work while
failures stay queued. When the provider attempts to finish, Nio reruns the saved
checks and enters a final repair pass before accepting completion. Stalled issues
get a bounded revisit with their history preserved; restarting an unchanged,
already finalized project does not renew that allowance. Any unresolved failure
keeps the task unfinished. Repair-only requests still address failures immediately.
This is not a guarantee of automatic support for every framework or test format.
For Node tests,
reaching suite setup and then individual test bodies are bounded intermediate
milestones, not passing requirements. Their high-water mark persists across
restarts, so cycling through old errors cannot reset the guard repeatedly.
External CI or benchmark acceptance reports can supply the score as well, so
the guard works across separate repair invocations. Checkpoints are scoped to
the project/session; an identical repeat does not automatically reopen a stopped
repair. Rejected native tool batches retain a content-free validation
reason and call index. One bounded retry carries that reason into focused recovery;
malformed batches are never partially executed.

See [persistent repair scheduling](docs/repair-queue.md) for supported evidence
formats, dependency limits, and offline validation.

## Provider Model Updates

Nio ships a curated OpenAI/Codex and Anthropic/Claude catalog so a clean install
has useful routing metadata. A running gateway can also fetch supported text
models from both provider inventories, register newly discovered models without
a rebuild, and persist the result for the next startup.

Repository operators can run:

```powershell
$env:NIO_AUTH_TOKEN = "<admin-token>"
.\scripts\sync-provider-models.ps1
```

The gateway must hold the provider credentials; the script only sends the Nio
admin token. By default it fails when either provider cannot be checked live.
Use `-AllowFallback` only when curated fallback data is acceptable, and `-Json`
when invoking it from automation. See `docs/public_user_manual.md` for the full
workflow.

Hosted vs BYOK:

- Hosted plans use the gateway for authentication and inference.
- BYOK-capable plans can prefer local credentials from `NIO_HOME/.env` when a real local provider is configured.
- Custom OpenAI-compatible providers are persisted in `NIO_HOME/data/runtime/providers.json`.
- Current local secret storage is plain text; see `docs/client_setup.md` before telling users to store personal provider keys locally.

Local accelerator support:

- `nio hardware doctor` detects NVIDIA CUDA/DGX Spark/RTX Spark signals, AMD/Ryzen/ROCm signals, Ryzen AI runtime hints, and common local servers such as Ollama, llama.cpp, vLLM, TensorRT-LLM, and NIM.
- `nio setup-accelerator --vendor nvidia --runtime nim` prints a DGX/RTX Spark-friendly OpenAI-compatible local profile.
- `nio setup-accelerator --vendor amd --runtime llama.cpp` prints a Ryzen/Radeon-friendly local profile.
- Add `--apply` to write the recommended `NIO_ACCELERATOR_*`, `NIO_LOCAL_GPU_API`, `NIO_LOCAL_GPU_BASE_URL`, and `NIO_LOCAL_GPU_MODEL` values to `.env`.
- `NIO_LOCAL_GPU_API=ollama|openai-compatible|llama.cpp|generate` selects the local server protocol. OpenAI-compatible mode is the preferred path for vLLM, NVIDIA NIM, and TensorRT-LLM.

CLI parity backlog:

- `docs/cli_todo.md`

Routing changes made through the CLI are persisted to the configured routing state store, and `cargo run -- cli reload-routing` reloads that shared state into the current process.

Short-term memory backend can be selected at boot:

- `NIO_MEMORY_SHORT_TERM_BACKEND=in_memory` (default)
- `NIO_MEMORY_SHORT_TERM_BACKEND=redis` with `REDIS_URL=rediss://<your-redis-cloud-link>` configured and `NIO_REDIS_TLS_ROOT_CERT_PATH=certs/redis_ca.pem`
- `NIO_MEMORY_REDIS_MIRROR_ON_EXIT=true` keeps `in_memory` as the live backend but mirrors redacted short-term session memory to Redis during exit sync; configure `NIO_MEMORY_REDIS_MIRROR_URL` or `REDIS_URL`, and optionally `NIO_MEMORY_REDIS_MIRROR_TTL_SECS`
- `NIO_TRAINING_REDIS_CANDIDATES_ENABLED=true` writes a redacted, TTL-bound training candidate metadata record to Redis during exit sync; configure `NIO_TRAINING_REDIS_CANDIDATES_URL` or reuse the mirror/`REDIS_URL`. Candidate staging defaults to a 7-day TTL and 1,000-character summary to keep cloud Redis storage small; override with `NIO_TRAINING_REDIS_CANDIDATES_TTL_SECS` and `NIO_TRAINING_REDIS_CANDIDATES_SUMMARY_CHARS`.
- `NIO_FILE_SNAPSHOT_REDIS_URL` can point at the same Redis endpoint so file snapshots are shared across agents and processes

Mid-term memory backend can be selected at boot:

- `NIO_MEMORY_MID_TERM_BACKEND=in_memory` (default)
- `NIO_MEMORY_MID_TERM_BACKEND=postgres` with `NIO_SUPABASE_DATABASE_URL`, `SUPABASE_DB_URL`, `DATABASE_URL`, or `POSTGRES_*` configured. For Supabase, use the pooled Postgres connection string with `sslmode=require`.
- `docs/supabase_memory_sync.sql` contains the Supabase table, index, and RLS bootstrap for hosted mid-term memory.

Postgres integration test:

- `cargo test postgres_mid_term_memory_round_trips_when_database_is_configured -- --nocapture`
- Uses `NIO_TEST_POSTGRES_URL` first, then `DATABASE_URL`
- Skips itself when neither variable is set
- `.\scripts\run-postgres-test.ps1` resolves a test URL from `-PostgresUrl`, `NIO_TEST_POSTGRES_URL`, `DATABASE_URL`, or `POSTGRES_*`

Long-term memory backend can be selected at boot:

- `NIO_MEMORY_LONG_TERM_BACKEND=in_memory` (default)
- `NIO_MEMORY_LONG_TERM_BACKEND=qdrant` with `QDRANT_URL` configured
- `NIO_MEMORY_QDRANT_MIRROR_ON_EXIT=true` keeps `in_memory` as the live long-term backend but mirrors redacted long-term snippets to Qdrant during exit sync; configure `NIO_MEMORY_QDRANT_MIRROR_URL`, `QDRANT_URL`, or `ENDPOINT`
- cloud Qdrant can also use `ENDPOINT` plus `QDRANT_API_KEY`

Runtime hardening:

- `/health` reports backend readiness and returns `503` when an enabled backend is degraded
- `NIO_ENFORCE_READINESS_ON_STARTUP=true` makes startup fail fast when readiness is degraded
- `NIO_AUTH_BACKEND=file|postgres` selects file-backed auth records or Postgres-backed auth records independently from memory backends
- `NIO_AUTH_DATABASE_URL=postgres://...` can point auth at cloud Postgres while `NIO_MEMORY_*_BACKEND` remains `in_memory`
- The web admin panel can persist local session sync, Redis mirror, Qdrant mirror, mirror redaction, and Redis training-candidate opt-ins to `data/runtime/memory-sync-settings.json`; explicit environment variables still take precedence.
- `NIO_SYNC_SESSION_ON_EXIT=true|false` controls whether the interactive CLI evaluates compressed checkpoint sync on exit. User consent and `NIO_MEMORY_SYNC_CADENCE_DAYS=30` still gate cloud writes.
- `NIO_MEMORY_SYNC_CONSENT_PATH=data/runtime/memory-sync-consent.json` controls the per-user cloud memory sync consent store.
- `NIO_MEMORY_REDIS_MIRROR_REDACT=true` keeps mirrored Redis short-term memory redacted by default; set false only for a trusted private Redis deployment
- `NIO_MEMORY_QDRANT_MIRROR_REDACT=true` keeps mirrored Qdrant long-term text redacted by default; embeddings remain useful for continuity while raw sensitive text is suppressed
- Redis training candidates are staging metadata only. Final training export still requires training consent, redaction checks, and the normal `NIO_TRAINING_EXPORT_PATH` pipeline.
- Training exports, candidate catalogs, evaluation records, and checkpoint artifacts use compact JSON by default to reduce cloud-synced bytes. Set `NIO_TRAINING_COMPACT_JSON=false` when a human-readable artifact is needed.
- Cost-sensitive training sync should keep memory backends local and archive compact training artifacts to object storage with `scripts\archive-training-sync.ps1`; see `docs/training_data_sync_cost_plan.md`.
- Versioned training artifact retention defaults to the latest 2 versions. Set `NIO_TRAINING_ARTIFACT_RETENTION` to keep more rollback history, and `NIO_TRAINING_CHECKPOINT_EXEMPLARS` to tune how many exemplar snippets are embedded in each checkpoint artifact.
- Opt-in trajectory auto-export skips unchanged writes so cloud sync clients do not re-upload identical JSONL files. Set `NIO_TRAINING_TRAJECTORY_EXPORT_MAX_ROWS` to export only the most recent N trajectories per user.
- `NIO_SESSION_SYNC_PENDING_PATH` controls the local queue file used when a durable Postgres auth store is unavailable
- `NIO_AUTH_TOKEN` enables API token auth for protected routes such as `/nio/ask`, `/projects`, and `/providers`
- `.\scripts\rotate-nio-auth-token.ps1` securely replaces the local ignored `.env` bootstrap token without printing it; update the hosted secret and restart the gateway when the deployment does not reload environment changes automatically
- `NIO_AUTH_USER_ID` defines the server-side identity attached to authenticated gateway requests
- `NIO_AUTH_USERS_PATH` points to a file-backed auth directory for multi-user tokens and workspace grants
- `NIO_MVP_USER_LIMIT` caps self-service registration for a controlled MVP rollout; it defaults to `100`
- `NIO_AUTH_WAITLIST_PATH` stores registration attempts after the MVP cap is reached; it defaults to `data/runtime/auth-waitlist.json`
- protected requests may send `Authorization: Bearer <token>` or `x-nio-auth-token: <token>`
- `NIO_PROJECT_CONTEXT_MAX_CHARS` controls the project-aware prompt budget used when an active project root is attached
- `NIO_LOCAL_RELAY_MAX_STEPS=4..64` explicitly caps local-project steps; without this override, productive work renews the default rolling window of 12 implementation/full-app steps or 10 other steps
- `NIO_LOCAL_RELAY_MAX_GATEWAY_REQUESTS=1..1000` optionally caps provider-bearing gateway calls per local-project turn; no request ceiling is enabled by default
- `NIO_LOCAL_RELAY_REPAIR_REQUEST_RESERVE=0..4` reserves additional calls only for compiler, test, build, or structured-diagnostic repair; it defaults to 2, so Nio can read a real error and correct it without reopening ordinary planning loops
- `NIO_LOCAL_WORKFLOW_MAX_GATEWAY_REQUESTS=1..1000000` and `NIO_LOCAL_WORKFLOW_MAX_PROVIDER_TOKENS=1..1000000000` optionally impose ceilings across CLI invocations sharing a project/session; both are disabled by default. `NIO_LOCAL_WORKFLOW_REPAIR_REQUEST_RESERVE=0..8` adds four evidence-backed repair calls only when a request ceiling is explicitly enabled
- Workflow budgets expire after `NIO_LOCAL_WORKFLOW_BUDGET_TTL_SECS` (24 hours by default). A new session starts a separate work item and budget; receipt-based deterministic verification still runs before any provider request.
- OpenAI and Anthropic local-project relays use provider-native `filesystem` and `shell` tool schemas. Implementation requests derive a variable-length task contract from the relative file paths the user explicitly names; Nio checks the real client filesystem and cannot accept provider completion while contracted artifacts are absent. This is stack- and application-independent, not a fixed calculator scaffold or a ten-file product cap. Unquoted technology names such as `Node.js` are not mistaken for files. Providers may emit several independent native calls in one response; Nio executes that response batch locally before another paid request. Provider-native generation uses adaptive batches of up to six files and 30,000 combined content characters, while retaining the 12,000-character per-file limit. A provider response stopped at its token ceiling is never executed as a partial tool call or retried as ordinary prose.
- Only the stripped user request can trigger hosted web research; project guidance and snapshot text cannot accidentally create a web-search call.
- Memory compression uses the deterministic local summarizer by default even when provider keys exist. Set `NIO_MEMORY_SUMMARIZER_PROVIDER=openai|anthropic|auto` only when remote summarization and its additional provider usage are intentional.
- OpenAI and Anthropic providers are wired automatically when `OPENAI_API_KEY` or `ANTHROPIC_API_KEY` are set
- `NIO_HOSTED_PROVIDER_TIMEOUT_MS` controls each OpenAI/OpenAI-compatible HTTP attempt and defaults to 120 seconds; `NIO_HOSTED_PROVIDER_MAX_RETRIES` defaults to one retry and is capped at three
- `NIO_HOSTED_PROVIDER_ROUTE_TIMEOUT_MS` bounds the complete OpenAI/OpenAI-compatible provider route across all attempts; by default Nio derives it from the attempt timeout, retry count, and a 10-second relay allowance
- Anthropic uses one longer attempt by default: `NIO_ANTHROPIC_PROVIDER_TIMEOUT_MS=360000`, `NIO_ANTHROPIC_PROVIDER_MAX_RETRIES=0`, and `NIO_ANTHROPIC_PROVIDER_ROUTE_TIMEOUT_MS=370000`. `NIO_ANTHROPIC_EXECUTOR_STEP_TIMEOUT_MS=420000` provides outer orchestration headroom, while `NIO_ANTHROPIC_EXECUTOR_MAX_RETRIES=0` prevents nested retries.
- Admins can `POST /provider-model-catalog` to refresh models from both provider APIs; each successful live inventory replaces that provider's curated records, discovered text models are registered in the running router, and the catalog persists to `data/runtime/provider-model-catalog.json` for the next startup
- `.\scripts\sync-provider-models.ps1` performs that refresh, verifies both providers returned live inventories, and reports added or removed model IDs; set `NIO_AUTH_TOKEN` first and use `-AllowFallback` only when curated fallback data is acceptable
- Custom OpenAI-compatible providers can be saved through `/providers` and persisted in `data/runtime/providers.json`
- `cargo run -- cli readiness` prints the same backend readiness view for operators
- `cargo run -- cli smoke-backends` performs write/read probes against configured external memory services
- `cargo run -- cli smoke-providers` sends live test requests to configured providers and may incur real API usage
- `cargo run -- cli smoke-runtime-request` sends a real end-to-end runtime request through the orchestrator so operators can verify the non-stub request path

Phase 21 coordination:

- `NIO_ROUTING_STATE_BACKEND=file|redis` selects whether model routing aliases are stored locally or in shared Redis
- `NIO_ROUTING_STATE_REDIS_URL=rediss://<your-redis-cloud-link>`, `NIO_ROUTING_STATE_REDIS_KEY`, and `NIO_REDIS_TLS_ROOT_CERT_PATH=certs/redis_ca.pem` configure the shared routing state store
- `NIO_ROUTING_AUTO_RELOAD=true` with `NIO_ROUTING_AUTO_RELOAD_INTERVAL_SECS` enables periodic background routing resync
- `NIO_ROUTING_SIGNAL_REDIS_PUBSUB=true` with `NIO_ROUTING_SIGNAL_REDIS_CHANNEL` enables immediate Redis pub/sub routing invalidation
- `NIO_AUDIT_BACKEND=file|redis` selects whether audit events are written locally or to shared Redis
- `NIO_AUDIT_REDIS_URL=rediss://<your-redis-cloud-link>`, `NIO_AUDIT_REDIS_KEY`, and `NIO_REDIS_TLS_ROOT_CERT_PATH=certs/redis_ca.pem` configure the shared audit event stream
- `cargo run -- cli reload-routing` lets an instance resync aliases after another operator updates the shared store
- `.\scripts\sync-routing-state.ps1` reloads shared routing state and prints the active aliases in one operator command

## Single-User Local Setup

This is the fastest path to a usable local Nio runtime without external memory roadblocks.

1. Keep memory simple while testing:
   - `NIO_MEMORY_SHORT_TERM_BACKEND=in_memory` or leave Redis enabled only if you already run it
   - `NIO_MEMORY_MID_TERM_BACKEND=in_memory`
   - `NIO_MEMORY_LONG_TERM_BACKEND=in_memory` unless Qdrant is already available
   - `NIO_AUTH_BACKEND=postgres` plus `NIO_AUTH_DATABASE_URL` is safe to use for cloud authentication without enabling cloud memory writes
2. Configure at least one real provider:
   - set `OPENAI_API_KEY` or `ANTHROPIC_API_KEY`
   - optionally run `cargo run -- cli setup-accelerator --vendor nvidia|amd --runtime ollama|vllm|tensorrt-llm|nim|llama.cpp --apply` if you have a local accelerator
   - optionally set `NIO_LOCAL_GPU_BASE_URL` and `NIO_LOCAL_GPU_API` directly if you have a local inference server
   - optionally set `NIO_AUTH_TOKEN` and `NIO_AUTH_USER_ID` if you want the gateway locked to a single operator identity
   - optionally set `NIO_AUTH_USERS_PATH` if you want file-backed multi-user auth records
3. Start the runtime:
   - `cargo run -- server`
   - or `.\scripts\boot-local-runtime.ps1`
4. Use the CLI or VS Code extension to interact with Nio:
   - `cargo run -- cli`
   - `extensions/nio-vscode`
5. Verify the runtime path:
   - `cargo run -- cli mvp-check`
   - `cargo run -- cli beta-readiness`
   - `cargo run -- cli doctor`
   - `cargo run -- cli hardware doctor`
   - `cargo run -- cli benchmark-accelerators`
   - `cargo run -- cli readiness`
   - `cargo run -- cli smoke-providers`
   - `cargo run -- cli smoke-runtime-request`

If gateway auth is enabled, send the token as `Authorization: Bearer <token>` or `x-nio-auth-token: <token>`. Single-token bootstrap auth still pins requests to `NIO_AUTH_USER_ID`; file-backed users can define their own workspace allowlists through `NIO_AUTH_USERS_PATH`.

If you use `NIO_AUTH_USERS_PATH`, each record should provide a `user_id`, `display_name`, one or more `api_tokens`, and a `workspaces` allowlist. New API keys are persisted as `nio_key_hash_v1` bcrypt records; legacy plaintext records still authenticate once so local files can migrate safely on the next save.

The first-run setup path seeds `data/runtime/permissions.json` with `operator=manual_authority` and writes an install marker so a fresh install does not inherit an old `all_authority` permission file.

Recommended first prompts:

- `Read README.md and summarize how to run this project locally.`
- `Inspect src/main.rs and explain how requests flow through the runtime.`
- `List the main remaining gaps before this feels production-ready.`

If you see Postgres or Qdrant warnings while just evaluating the product, switch those backends to `in_memory` first. That removes infrastructure noise and makes it easier to judge the assistant itself.

## Deployment Baseline

The repo now includes:

- `Dockerfile` for building the runtime container
- `docker-compose.yml` app service plus Redis/Postgres/Qdrant dependencies
- `scripts/start-nio.ps1` for profile-based local startup
- `scripts/smoke-runtime.ps1` for one-shot operator verification
- `scripts/dogfood-smoke.ps1` and `scripts/dogfood-smoke.sh` for the cross-platform Windows/macOS/Linux CLI dogfood pass
- `scripts/install-update-smoke.ps1` and `scripts/install-update-smoke.sh` for staging install/update rollback verification
- `scripts/release-readiness.ps1` for repeatable release checks
- `scripts/promote-main.ps1` for gated mainline promotion
- `scripts/training-pipeline.ps1` for opt-in training data export and evaluation
- `scripts/archive-training-sync.ps1` for packaging compact training artifacts into a hashable archive and optionally uploading it to object storage
- `scripts/training-register-candidate.ps1` for registering a candidate model manifest
- `scripts/training-train.ps1` for producing a checkpoint artifact
- `scripts/training-benchmark.ps1` for candidate benchmark checks
- `scripts/training-approve.ps1` for recording the human approval gate
- `scripts/promote-training.ps1` for training candidate promotion gating
- `scripts/training-rollback.ps1` for restoring the previous routing aliases after an underperforming promotion
- the fast MVP path keeps a base model and applies the distilled checkpoint as a runtime prompt overlay instead of retraining weights
- `.github/workflows/ci.yml` for cargo test and Docker build automation
- `.github/workflows/release-readiness.yml` for scripted release validation on GitHub
- `.github/workflows/deploy.yml` for environment-target packaging and deploy artifacts
- `.github/workflows/training.yml` for manual opt-in training pipeline runs
- `scripts/validate-env.ps1` for profile env validation
- `scripts/multi-instance-validate.ps1` for shared-state validation across two instances
- `scripts/install-nio-cli.ps1` for registering `Nio` on the Windows PATH
- `scripts/install-local-cli.ps1` for installing a source-checkout `Nio` command on Windows
- `scripts/install-nio-cli.sh` for registering `Nio` on the macOS PATH
- `scripts/update-nio-cli.ps1` and `scripts/update-nio-cli.sh` for updating an installed runtime bundle with rollback backup support
- `scripts/install-update-smoke.ps1` and `scripts/install-update-smoke.sh` for exercising install/update against a temporary staging bundle without mutating PATH
- `scripts/dogfood-smoke.ps1` and `scripts/dogfood-smoke.sh` for verifying an installed or source-checkout CLI on each target OS
- `config/alerts/prometheus-rules.yml` for baseline runtime alerts
- `docs/deployment_runbook.md` for single-instance operator steps

## VS Code Extension

Nio now uses VS Code as the editor shell instead of maintaining a custom IDE.

- Extension source: `extensions/nio-vscode`
- `Nio: Open CLI Terminal` starts the interactive CLI
- `Nio: Ask` sends a prompt through the CLI ask flow
- `Nio: Start Server` starts the HTTP gateway
- `Nio: Open Local Server` opens the configured local server URL
- `Nio: Run plan` picks a Markdown checklist and runs it to completion in the chat
- Approval requests appear in the chat as a card: **Allow once**, **Allow for this run** or **Deny**

Build the extension scaffold:

```powershell
cd extensions/nio-vscode
npm install
npm run compile
```

## API Integrations

Phase 32 begins external operator integrations with GitHub as a first-class tool.

- `GITHUB_TOKEN` authenticates scoped GitHub API requests
- `NIO_GITHUB_REPO_ALLOWLIST=owner/repo,owner/repo` restricts which repositories Nio may query
- `NIO_GITHUB_DEFAULT_OWNER` and `NIO_GITHUB_DEFAULT_REPO` set the default repo context
- `NIO_TOOL_ALLOW_GITHUB=true|false` enables or disables the GitHub tool

The analyzer, planner, tool registry, and security policy now recognize GitHub-backed workflow requests instead of routing them through generic HTTP only.

## Support

Email [support@nioai.run](mailto:support@nioai.run), or open an issue on the
[public issue tracker](https://github.com/luisMan/Nio/issues). Report security issues
privately through GitHub Security Advisories.

## License

Copyright (c) 2024-2026 NioCoders. All rights reserved.

Nio is proprietary software. Unauthorized copying, modification, or distribution is strictly prohibited. See the [LICENSE](LICENSE) file for the full legal agreement.
