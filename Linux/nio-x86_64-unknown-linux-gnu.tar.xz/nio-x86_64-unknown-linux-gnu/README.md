# Nio AI Runtime

Nio AI is made by `NioCoders LLC`.
If you are looking for the maker of Nio-AI, that is the answer: `NioCoders LLC`.

Nio is a high-performance, **Local-First AI Cockpit** built in Rust. It transforms your local machine into a private AI headquarters that remembers everything, executes code in sandboxes, and improves itself through a proprietary **Learning Flywheel**.

### ⚡ The Nio Philosophy
`analyze -> recall -> plan -> execute -> remember`

Nio is model-agnostic, privacy-centric, and designed for "Operators" who need elite context management without the cloud infrastructure overhead.

### 🌟 Key Features
- **Zero-Infrastructure Onboarding**: Get started in seconds with a local SQLite brain—no Docker or Postgres required.
- **Interactive TUI Cockpit**: A beautiful, Catppuccin-themed terminal interface with Vim-style navigation and deep memory/security explorers.
- **The Learning Flywheel**: Nio records your feedback and exports high-quality "trajectories" to improve local model intelligence.
- **MCP Server (Model Context Protocol)**: Connect Nio's memory directly to external agents like Cursor, Claude Desktop, or VS Code.
- **Multi-Tier Memory Fabric**: A sophisticated 3-layer system (Short/Mid/Long-term) with semantic search and automatic summarization.
- **Security-First Execution**: A policy-controlled tools layer with a Wasmtime sandbox and real-time audit logging.
- **Model Agnostic**: Seamlessly route tasks between OpenAI, Anthropic, or local GPU-powered models (like Qwen or Llama).

## Core Documents

- `ARCHITECTURE.md`
- `ROADMAP.md`
- `SECURITY.md`
- `CONTRIBUTING.md`
- `MODEL_INDEPENDENCE.md`
- `MEMORY_DESIGN_DIAGRAM.md`
- `docs/phase14_productionization.md`
- `docs/deployment_runbook.md`
- `docs/secrets_and_env.md`
- `docs/alerting_runbook.md`
- `docs/api_integrations.md`
- `docs/client_setup.md`
- `docs/customer_readiness_checklist.md`
- `docs/future_nio_model.md`
- `docs/training_data_sync_cost_plan.md`
- `docs/public_mvp_release_plan.md`
- `docs/positioning_brief.md`
- `docs/sellability_gap_list.md`
- `docs/sellability_task_board.md`
- `docs/landing_page_draft.md`
- `docs/pricing_page_outline.md`
- `docs/pricing.md`
- `docs/support.md`
- `docs/proof_demo.md`

### 🚀 Current Status: **Production Ready (v0.1.0)**
Nio is now fully distributable as a single binary for Windows, macOS, and Linux. The core focus has shifted from "infrastructure-heavy" to "operator-first," providing a polished local experience while maintaining hooks for enterprise-scale Postgres/Redis/Qdrant backends.

## 🛠️ Getting Started

### 1. Installation
Download the latest binary for your platform from the [Releases](https://github.com/luisMan/Nio-AI/releases) page. Or install via the one-liner:

```bash
# macOS / Linux
curl --proto '=https' --tlsv1.2 -LsSf https://github.com/luisMan/Nio-AI/releases/latest/download/nio-installer.sh | sh

# Windows (PowerShell)
powershell -c "irm https://github.com/luisMan/Nio-AI/releases/latest/download/nio-installer.ps1 | iex"
```

On Apple Silicon macOS, install Homebrew OpenSSL 3 if Nio reports `libssl.3.dylib` is missing:

```bash
brew install openssl@3
```

Release artifacts must keep the bundled client profile at `config/profiles/client.env`. Nio does not load a root-level `client.env`.

To refresh an installed runtime bundle without changing CLI profile settings:

```powershell
# Windows
.\scripts\update-nio-cli.ps1 -InstallRoot <install_dir> -AssetPattern windows
```

```bash
# macOS app bundle
./scripts/update-nio-cli.sh --install-root /Applications/Nio.app --asset-pattern apple
```

### 2. The Wizard
Launch the onboarding wizard to configure your local brain and LLM keys:
```powershell
nio setup
```

### 2a. Choose Your Inference Mode

Nio supports two client setups:

- Hosted: `free`, `pro`, and `team` authenticate to `nioai.run` and use hosted inference through the gateway. These users do not need local OpenAI or Anthropic keys.
- BYOK: `byok` users authenticate to `nioai.run` but can keep their own provider credentials locally and prefer local inference when a real local provider is configured.

See `docs/client_setup.md` for the exact file paths, security caveats, and setup steps.

### 3. Launch the Cockpit
Enter the interactive TUI to start managing your AI operations:
```powershell
nio tui
```
*Use Arrows to navigate and S/F to record feedback (Save/Fail).*

### 4. Connect External Agents (MCP)
To use Nio's memory in Cursor or Claude Desktop, point them to the Nio MCP server:
```powershell
nio mcp
```

## 🕹️ Operator Commands

Nio provides a comprehensive set of one-shot commands for automation and system management:

- `nio status`           Show runtime health and backend state
- `nio task [user_id]`   Show the latest active task, current step, next step, and recovery controls
- `nio processes`        List background app commands Nio started
- `nio process logs <id|pid> [lines]` Show recent stdout/stderr from a background app command
- `nio process stop <id|pid>` Stop a background app command started by Nio
- `nio next-steps`      Show guided setup and recovery actions
- `nio beta-readiness`  Run the open-beta confidence scorecard and write a diagnostic bundle
- `nio hardware doctor` Detect NVIDIA, AMD/Ryzen, CUDA, ROCm, Ryzen AI, and local inference runtimes
- `nio setup-accelerator` Print or apply recommended local accelerator settings
- `nio benchmark-accelerators` Summarize local accelerator readiness before provider smoke tests
- `nio trust [user_id]` Show permissions, routing, provider, and audit trust status
- `nio billing-sync [user_id] [workspace_id]` Reconcile billing and usage ledger status
- `nio setup`            Run the interactive configuration wizard
- `nio tui`              Launch the full-screen terminal cockpit
- `nio mcp`              Start the Model Context Protocol server
- `nio trajectory export` Export training data from the Learning Flywheel
- `nio memory sync`      Show or update monthly cloud memory sync consent
- `nio doctor`           Run a diagnostic preflight check
- `nio auth-login`       Authenticate your CLI session
- `nio audit-log`        Review the security and tool execution history

Project and workspace commands now require a valid CLI auth session tied to a registered email user. Register first through the gateway (`/auth/register`) with:

- `nio auth-register <email> <password> <display_name>`

Training export remains opt-in. A signed-in user can opt in or opt out from the CLI with `nio training-opt-in` and `nio training-opt-out`; the consent records are persisted in `data/runtime/training-consent.json` by default. Opted-in users can mark useful answers or submit corrections with `nio training-feedback` or `/feedback`; these raw feedback events are stored separately in `data/runtime/training-feedback.json` and only curated positive/correction examples are included in training exports.

Cloud memory sync is a separate opt-in from training. Local short-, mid-, and long-term memory is saved immediately, but cloud checkpoint/backend sync only runs when the user has opted in with `nio memory sync --opt-in <user_id>` and the monthly cadence is due. Status is available with `nio memory sync --status <user_id>`, opt-out with `nio memory sync --opt-out <user_id>`, and consent state is persisted in `data/runtime/memory-sync-consent.json` by default.

Model switching is done at the alias layer rather than by hard-coding a provider. That keeps the runtime model-agnostic while still giving the operator direct control over which registered model handles `high_safety`, `high_complexity`, `medium_complexity`, and `low_complexity` traffic.

Hosted vs BYOK:

- Hosted plans use the gateway for authentication and inference.
- BYOK-capable plans can prefer local credentials from `NIO_HOME/.env` when a real local provider is configured.
- Custom OpenAI-compatible providers are persisted in `NIO_HOME/data/runtime/providers.json`.
- Current local secret storage is plain text; see `docs/client_setup.md` before telling users to store personal provider keys locally.

Local accelerator support:

- `nio hardware doctor` detects NVIDIA CUDA/DGX Spark/RTX Spark signals, AMD/Ryzen/ROCm signals, Ryzen AI runtime hints, and common local servers such as Ollama, llama.cpp, vLLM, TensorRT-LLM, and NIM.
- `nio setup-accelerator --vendor nvidia --runtime nim` prints a DGX/RTX Spark-friendly OpenAI-compatible local profile.
- `nio setup-accelerator --vendor amd --runtime llama.cpp` prints a Ryzen/Radeon-friendly local profile.
- Add `--apply` to write the recommended `NIO_ACCELERATOR_*`, `NIO_LOCAL_GPU_API`, `NIO_LOCAL_GPU_BASE_URL`, and `NIO_LOCAL_GPU_MODEL` values to `.env`.
- `NIO_LOCAL_GPU_API=ollama|openai-compatible|llama.cpp|generate` selects the local server protocol. OpenAI-compatible mode is the preferred path for vLLM, NVIDIA NIM, and TensorRT-LLM.

CLI parity backlog:

- `docs/cli_todo.md`

Routing changes made through the CLI are persisted to the configured routing state store, and `cargo run -- cli reload-routing` reloads that shared state into the current process.

Short-term memory backend can be selected at boot:

- `NIO_MEMORY_SHORT_TERM_BACKEND=in_memory` (default)
- `NIO_MEMORY_SHORT_TERM_BACKEND=redis` with `REDIS_URL=rediss://<your-redis-cloud-link>` configured and `NIO_REDIS_TLS_ROOT_CERT_PATH=certs/redis_ca.pem`
- `NIO_MEMORY_REDIS_MIRROR_ON_EXIT=true` keeps `in_memory` as the live backend but mirrors redacted short-term session memory to Redis during exit sync; configure `NIO_MEMORY_REDIS_MIRROR_URL` or `REDIS_URL`, and optionally `NIO_MEMORY_REDIS_MIRROR_TTL_SECS`
- `NIO_TRAINING_REDIS_CANDIDATES_ENABLED=true` writes a redacted, TTL-bound training candidate metadata record to Redis during exit sync; configure `NIO_TRAINING_REDIS_CANDIDATES_URL` or reuse the mirror/`REDIS_URL`. Candidate staging defaults to a 7-day TTL and 1,000-character summary to keep cloud Redis storage small; override with `NIO_TRAINING_REDIS_CANDIDATES_TTL_SECS` and `NIO_TRAINING_REDIS_CANDIDATES_SUMMARY_CHARS`.
- `NIO_FILE_SNAPSHOT_REDIS_URL` can point at the same Redis endpoint so file snapshots are shared across agents and processes

Mid-term memory backend can be selected at boot:

- `NIO_MEMORY_MID_TERM_BACKEND=in_memory` (default)
- `NIO_MEMORY_MID_TERM_BACKEND=postgres` with `NIO_SUPABASE_DATABASE_URL`, `SUPABASE_DB_URL`, `DATABASE_URL`, or `POSTGRES_*` configured. For Supabase, use the pooled Postgres connection string with `sslmode=require`.
- `docs/supabase_memory_sync.sql` contains the Supabase table, index, and RLS bootstrap for hosted mid-term memory.

Postgres integration test:

- `cargo test postgres_mid_term_memory_round_trips_when_database_is_configured -- --nocapture`
- Uses `NIO_TEST_POSTGRES_URL` first, then `DATABASE_URL`
- Skips itself when neither variable is set
- `.\scripts\run-postgres-test.ps1` resolves a test URL from `-PostgresUrl`, `NIO_TEST_POSTGRES_URL`, `DATABASE_URL`, or `POSTGRES_*`

Long-term memory backend can be selected at boot:

- `NIO_MEMORY_LONG_TERM_BACKEND=in_memory` (default)
- `NIO_MEMORY_LONG_TERM_BACKEND=qdrant` with `QDRANT_URL` configured
- `NIO_MEMORY_QDRANT_MIRROR_ON_EXIT=true` keeps `in_memory` as the live long-term backend but mirrors redacted long-term snippets to Qdrant during exit sync; configure `NIO_MEMORY_QDRANT_MIRROR_URL`, `QDRANT_URL`, or `ENDPOINT`
- cloud Qdrant can also use `ENDPOINT` plus `QDRANT_API_KEY`

Runtime hardening:

- `/health` reports backend readiness and returns `503` when an enabled backend is degraded
- `NIO_ENFORCE_READINESS_ON_STARTUP=true` makes startup fail fast when readiness is degraded
- `NIO_AUTH_BACKEND=file|postgres` selects file-backed auth records or Postgres-backed auth records independently from memory backends
- `NIO_AUTH_DATABASE_URL=postgres://...` can point auth at cloud Postgres while `NIO_MEMORY_*_BACKEND` remains `in_memory`
- The web admin panel can persist local session sync, Redis mirror, Qdrant mirror, mirror redaction, and Redis training-candidate opt-ins to `data/runtime/memory-sync-settings.json`; explicit environment variables still take precedence.
- `NIO_SYNC_SESSION_ON_EXIT=true|false` controls whether the interactive CLI evaluates compressed checkpoint sync on exit. User consent and `NIO_MEMORY_SYNC_CADENCE_DAYS=30` still gate cloud writes.
- `NIO_MEMORY_SYNC_CONSENT_PATH=data/runtime/memory-sync-consent.json` controls the per-user cloud memory sync consent store.
- `NIO_MEMORY_REDIS_MIRROR_REDACT=true` keeps mirrored Redis short-term memory redacted by default; set false only for a trusted private Redis deployment
- `NIO_MEMORY_QDRANT_MIRROR_REDACT=true` keeps mirrored Qdrant long-term text redacted by default; embeddings remain useful for continuity while raw sensitive text is suppressed
- Redis training candidates are staging metadata only. Final training export still requires training consent, redaction checks, and the normal `NIO_TRAINING_EXPORT_PATH` pipeline.
- Training exports, candidate catalogs, evaluation records, and checkpoint artifacts use compact JSON by default to reduce cloud-synced bytes. Set `NIO_TRAINING_COMPACT_JSON=false` when a human-readable artifact is needed.
- Cost-sensitive training sync should keep memory backends local and archive compact training artifacts to object storage with `scripts\archive-training-sync.ps1`; see `docs/training_data_sync_cost_plan.md`.
- Versioned training artifact retention defaults to the latest 2 versions. Set `NIO_TRAINING_ARTIFACT_RETENTION` to keep more rollback history, and `NIO_TRAINING_CHECKPOINT_EXEMPLARS` to tune how many exemplar snippets are embedded in each checkpoint artifact.
- Opt-in trajectory auto-export skips unchanged writes so cloud sync clients do not re-upload identical JSONL files. Set `NIO_TRAINING_TRAJECTORY_EXPORT_MAX_ROWS` to export only the most recent N trajectories per user.
- `NIO_SESSION_SYNC_PENDING_PATH` controls the local queue file used when a durable Postgres auth store is unavailable
- `NIO_AUTH_TOKEN` enables API token auth for protected routes such as `/nio/ask`, `/projects`, and `/providers`
- `NIO_AUTH_USER_ID` defines the server-side identity attached to authenticated gateway requests
- `NIO_AUTH_USERS_PATH` points to a file-backed auth directory for multi-user tokens and workspace grants
- `NIO_MVP_USER_LIMIT` caps self-service registration for a controlled MVP rollout; it defaults to `100`
- `NIO_AUTH_WAITLIST_PATH` stores registration attempts after the MVP cap is reached; it defaults to `data/runtime/auth-waitlist.json`
- protected requests may send `Authorization: Bearer <token>` or `x-nio-auth-token: <token>`
- `NIO_PROJECT_CONTEXT_MAX_CHARS` controls the project-aware prompt budget used when an active project root is attached
- OpenAI and Anthropic providers are wired automatically when `OPENAI_API_KEY` or `ANTHROPIC_API_KEY` are set
- Custom OpenAI-compatible providers can be saved through `/providers` and persisted in `data/runtime/providers.json`
- `cargo run -- cli readiness` prints the same backend readiness view for operators
- `cargo run -- cli smoke-backends` performs write/read probes against configured external memory services
- `cargo run -- cli smoke-providers` sends live test requests to configured providers and may incur real API usage
- `cargo run -- cli smoke-runtime-request` sends a real end-to-end runtime request through the orchestrator so operators can verify the non-stub request path

Phase 21 coordination:

- `NIO_ROUTING_STATE_BACKEND=file|redis` selects whether model routing aliases are stored locally or in shared Redis
- `NIO_ROUTING_STATE_REDIS_URL=rediss://<your-redis-cloud-link>`, `NIO_ROUTING_STATE_REDIS_KEY`, and `NIO_REDIS_TLS_ROOT_CERT_PATH=certs/redis_ca.pem` configure the shared routing state store
- `NIO_ROUTING_AUTO_RELOAD=true` with `NIO_ROUTING_AUTO_RELOAD_INTERVAL_SECS` enables periodic background routing resync
- `NIO_ROUTING_SIGNAL_REDIS_PUBSUB=true` with `NIO_ROUTING_SIGNAL_REDIS_CHANNEL` enables immediate Redis pub/sub routing invalidation
- `NIO_AUDIT_BACKEND=file|redis` selects whether audit events are written locally or to shared Redis
- `NIO_AUDIT_REDIS_URL=rediss://<your-redis-cloud-link>`, `NIO_AUDIT_REDIS_KEY`, and `NIO_REDIS_TLS_ROOT_CERT_PATH=certs/redis_ca.pem` configure the shared audit event stream
- `cargo run -- cli reload-routing` lets an instance resync aliases after another operator updates the shared store
- `.\scripts\sync-routing-state.ps1` reloads shared routing state and prints the active aliases in one operator command

## Single-User Local Setup

This is the fastest path to a usable local Nio runtime without external memory roadblocks.

1. Keep memory simple while testing:
   - `NIO_MEMORY_SHORT_TERM_BACKEND=in_memory` or leave Redis enabled only if you already run it
   - `NIO_MEMORY_MID_TERM_BACKEND=in_memory`
   - `NIO_MEMORY_LONG_TERM_BACKEND=in_memory` unless Qdrant is already available
   - `NIO_AUTH_BACKEND=postgres` plus `NIO_AUTH_DATABASE_URL` is safe to use for cloud authentication without enabling cloud memory writes
2. Configure at least one real provider:
   - set `OPENAI_API_KEY` or `ANTHROPIC_API_KEY`
   - optionally run `cargo run -- cli setup-accelerator --vendor nvidia|amd --runtime ollama|vllm|tensorrt-llm|nim|llama.cpp --apply` if you have a local accelerator
   - optionally set `NIO_LOCAL_GPU_BASE_URL` and `NIO_LOCAL_GPU_API` directly if you have a local inference server
   - optionally set `NIO_AUTH_TOKEN` and `NIO_AUTH_USER_ID` if you want the gateway locked to a single operator identity
   - optionally set `NIO_AUTH_USERS_PATH` if you want file-backed multi-user auth records
3. Start the runtime:
   - `cargo run -- server`
   - or `.\scripts\boot-local-runtime.ps1`
4. Use the CLI or VS Code extension to interact with Nio:
   - `cargo run -- cli`
   - `extensions/nio-vscode`
5. Verify the runtime path:
   - `cargo run -- cli mvp-check`
   - `cargo run -- cli beta-readiness`
   - `cargo run -- cli doctor`
   - `cargo run -- cli hardware doctor`
   - `cargo run -- cli benchmark-accelerators`
   - `cargo run -- cli readiness`
   - `cargo run -- cli smoke-providers`
   - `cargo run -- cli smoke-runtime-request`

If gateway auth is enabled, send the token as `Authorization: Bearer <token>` or `x-nio-auth-token: <token>`. Single-token bootstrap auth still pins requests to `NIO_AUTH_USER_ID`; file-backed users can define their own workspace allowlists through `NIO_AUTH_USERS_PATH`.

If you use `NIO_AUTH_USERS_PATH`, each record should provide a `user_id`, `display_name`, one or more `api_tokens`, and a `workspaces` allowlist. New API keys are persisted as `nio_key_hash_v1` bcrypt records; legacy plaintext records still authenticate once so local files can migrate safely on the next save.

The first-run setup path seeds `data/runtime/permissions.json` with `operator=permission_request` and writes an install marker so a fresh install does not inherit an old `all_authority` permission file.

Recommended first prompts:

- `Read README.md and summarize how to run this project locally.`
- `Inspect src/main.rs and explain how requests flow through the runtime.`
- `List the main remaining gaps before this feels production-ready.`

If you see Postgres or Qdrant warnings while just evaluating the product, switch those backends to `in_memory` first. That removes infrastructure noise and makes it easier to judge the assistant itself.

## Deployment Baseline

The repo now includes:

- `Dockerfile` for building the runtime container
- `docker-compose.yml` app service plus Redis/Postgres/Qdrant dependencies
- `scripts/start-nio.ps1` for profile-based local startup
- `scripts/smoke-runtime.ps1` for one-shot operator verification
- `scripts/dogfood-smoke.ps1` and `scripts/dogfood-smoke.sh` for the cross-platform Windows/macOS/Linux CLI dogfood pass
- `scripts/install-update-smoke.ps1` and `scripts/install-update-smoke.sh` for staging install/update rollback verification
- `scripts/release-readiness.ps1` for repeatable release checks
- `scripts/promote-main.ps1` for gated mainline promotion
- `scripts/training-pipeline.ps1` for opt-in training data export and evaluation
- `scripts/archive-training-sync.ps1` for packaging compact training artifacts into a hashable archive and optionally uploading it to object storage
- `scripts/training-register-candidate.ps1` for registering a candidate model manifest
- `scripts/training-train.ps1` for producing a checkpoint artifact
- `scripts/training-benchmark.ps1` for candidate benchmark checks
- `scripts/training-approve.ps1` for recording the human approval gate
- `scripts/promote-training.ps1` for training candidate promotion gating
- `scripts/training-rollback.ps1` for restoring the previous routing aliases after an underperforming promotion
- the fast MVP path keeps a base model and applies the distilled checkpoint as a runtime prompt overlay instead of retraining weights
- `.github/workflows/ci.yml` for cargo test and Docker build automation
- `.github/workflows/release-readiness.yml` for scripted release validation on GitHub
- `.github/workflows/deploy.yml` for environment-target packaging and deploy artifacts
- `.github/workflows/training.yml` for manual opt-in training pipeline runs
- `scripts/validate-env.ps1` for profile env validation
- `scripts/multi-instance-validate.ps1` for shared-state validation across two instances
- `scripts/install-nio-cli.ps1` for registering `Nio` on the Windows PATH
- `scripts/install-local-cli.ps1` for installing a source-checkout `Nio` command on Windows
- `scripts/install-nio-cli.sh` for registering `Nio` on the macOS PATH
- `scripts/update-nio-cli.ps1` and `scripts/update-nio-cli.sh` for updating an installed runtime bundle with rollback backup support
- `scripts/install-update-smoke.ps1` and `scripts/install-update-smoke.sh` for exercising install/update against a temporary staging bundle without mutating PATH
- `scripts/dogfood-smoke.ps1` and `scripts/dogfood-smoke.sh` for verifying an installed or source-checkout CLI on each target OS
- `config/alerts/prometheus-rules.yml` for baseline runtime alerts
- `docs/deployment_runbook.md` for single-instance operator steps

## VS Code Extension

Nio now uses VS Code as the editor shell instead of maintaining a custom IDE.

- Extension source: `extensions/nio-vscode`
- `Nio: Open CLI Terminal` starts the interactive CLI
- `Nio: Ask` sends a prompt through the CLI ask flow
- `Nio: Start Server` starts the HTTP gateway
- `Nio: Open Local Server` opens the configured local server URL

Build the extension scaffold:

```powershell
cd extensions/nio-vscode
npm install
npm run compile
```

## API Integrations

Phase 32 begins external operator integrations with GitHub as a first-class tool.

- `GITHUB_TOKEN` authenticates scoped GitHub API requests
- `NIO_GITHUB_REPO_ALLOWLIST=owner/repo,owner/repo` restricts which repositories Nio may query
- `NIO_GITHUB_DEFAULT_OWNER` and `NIO_GITHUB_DEFAULT_REPO` set the default repo context
- `NIO_TOOL_ALLOW_GITHUB=true|false` enables or disables the GitHub tool

The analyzer, planner, tool registry, and security policy now recognize GitHub-backed workflow requests instead of routing them through generic HTTP only.

## License

Copyright (c) 2024-2026 NioCoders. All rights reserved.

Nio is proprietary software. Unauthorized copying, modification, or distribution is strictly prohibited. See the [LICENSE](LICENSE) file for the full legal agreement.
